import BottomBar from "../components/BottomBar.jsx";

const ActivityPage = ()  => {
    return (
        <div>
            <div>활동페이지</div>
            <BottomBar activeTab="activity" />
        </div>
    )
}

export default ActivityPage